import fs from "node:fs";
import path from "node:path";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import {
  CredentialError,
  credentialBindingsEqual,
  inspectWriterLock,
  type CredentialBinding,
  type CredentialVault,
  type ManagerResult,
} from "../src/index.js";
import {
  createNodeLappManagerHost,
  createNodeLappManagerHostV2,
} from "../src/manager/host.js";
import { MODEL_PREVIEW_LIMIT, MODEL_PREVIEW_TTL_MS } from "../src/manager/previews.js";

const roots: string[] = [];
let previousStateHome: string | undefined;

function temporaryRoot(): string {
  const root = fs.mkdtempSync(path.join(process.cwd(), ".manager-v2-test-"));
  roots.push(root);
  return root;
}

function uuid(n: number): string {
  return `00000000-0000-4000-8000-${String(n).padStart(12, "0")}`;
}

beforeEach(() => {
  previousStateHome = process.env.LAPP_STATE_HOME;
  process.env.LAPP_STATE_HOME = temporaryRoot();
});

afterEach(() => {
  vi.restoreAllMocks();
  if (previousStateHome === undefined) delete process.env.LAPP_STATE_HOME;
  else process.env.LAPP_STATE_HOME = previousStateHome;
  for (const root of roots.splice(0)) fs.rmSync(root, { recursive: true, force: true });
});

function unwrap<T>(result: ManagerResult<T>): T {
  if (!result.ok) throw new Error(`${result.error.code}: ${result.error.message}`);
  return result.value;
}

class MemoryVault implements CredentialVault {
  readonly records = new Map<string, { secret: string; binding: CredentialBinding }>();
  resolveCalls = 0;
  statusCalls = 0;

  async put(
    reference: string,
    secret: string,
    binding: CredentialBinding,
    options: { overwrite?: boolean } = {},
  ): Promise<void> {
    if (this.records.has(reference) && !options.overwrite) {
      throw new CredentialError("VAULT_CREDENTIAL_EXISTS", "vault credential already exists");
    }
    this.records.set(reference, { secret, binding: structuredClone(binding) });
  }

  async resolve(reference: string, binding: CredentialBinding): Promise<string> {
    this.resolveCalls += 1;
    const record = this.records.get(reference);
    if (!record) {
      throw new CredentialError("VAULT_CREDENTIAL_NOT_FOUND", "vault credential was not found");
    }
    if (!credentialBindingsEqual(record.binding, binding)) {
      throw new CredentialError("VAULT_BINDING_MISMATCH", "vault binding mismatch");
    }
    return record.secret;
  }

  async status(reference: string, binding: CredentialBinding) {
    this.statusCalls += 1;
    const record = this.records.get(reference);
    return record
      ? {
          reference,
          exists: true,
          bindingMatches: credentialBindingsEqual(record.binding, binding),
        }
      : { reference, exists: false };
  }

  async delete(reference: string): Promise<boolean> {
    return this.records.delete(reference);
  }
}

function discoveryProvider(secret: string) {
  return {
    type: "provider.set" as const,
    input: {
      id: "provider",
      name: "Provider",
      baseUrl: "http://127.0.0.1:8080/v1",
      protocols: ["openai-chat-completions"],
      models: [{ id: "model-a" }],
      auth: {
        type: "bearer" as const,
        credential: { secret },
      },
      modelDiscovery: {
        protocol: "openai-models" as const,
        url: "http://127.0.0.1:8080/v1/models",
      },
    },
  };
}

function modelsResponse(models: Array<{ id: string; name?: string }>): Response {
  return new Response(JSON.stringify({ data: models }), {
    status: 200,
    headers: { "content-type": "application/json" },
  });
}

async function seededHost(options: {
  fetchImpl?: typeof fetch;
  now?: () => number;
  vault?: MemoryVault;
  lock?: { stateHome: string; timeoutMs?: number; retryDelayMs?: number };
} = {}) {
  const root = temporaryRoot();
  const vault = options.vault ?? new MemoryVault();
  const host = createNodeLappManagerHostV2({
    path: root,
    vault,
    ...(options.fetchImpl ? { fetchImpl: options.fetchImpl } : {}),
    ...(options.now ? { now: options.now } : {}),
    ...(options.lock ? { lock: options.lock } : {}),
  });
  const initial = unwrap(await host.getSnapshot());
  const created = unwrap(await host.transact({
    expectedRevision: initial.revision,
    operation: discoveryProvider("sk-manager-v2-secret"),
  }));
  vault.resolveCalls = 0;
  vault.statusCalls = 0;
  return { root, vault, host, revision: created.revision };
}

describe("Node LAPP manager host V2", () => {
  it("advertises protocol 2 without changing the V1 handshake", async () => {
    const v1 = createNodeLappManagerHost({ path: temporaryRoot(), vault: new MemoryVault() });
    const v2 = createNodeLappManagerHostV2({ path: temporaryRoot(), vault: new MemoryVault() });
    expect(unwrap(await v1.handshake())).toEqual({
      protocolVersion: 1,
      features: ["write-profile", "vault", "test-connection", "refresh-models", "events"],
    });
    expect(unwrap(await v2.handshake())).toEqual({
      protocolVersion: 2,
      features: [
        "write-profile",
        "vault",
        "test-connection",
        "refresh-models",
        "events",
        "preview-models",
        "apply-models",
        "test-connection-v2",
      ],
    });
  });

  it("rejects a stale preview revision before Vault or network access", async () => {
    let fetches = 0;
    const { host, vault } = await seededHost({
      fetchImpl: async () => {
        fetches += 1;
        throw new Error("network must not run");
      },
    });
    const result = await host.previewModels({
      operationId: uuid(1),
      providerId: "provider",
      expectedRevision: "sha256:stale",
    });
    expect(result).toMatchObject({ ok: false, error: { code: "PROFILE_CONFLICT" } });
    expect(vault.resolveCalls).toBe(0);
    expect(fetches).toBe(0);
  });

  it("rejects a stale V2 connection test before Vault or network access", async () => {
    let fetches = 0;
    const { host, vault } = await seededHost({
      fetchImpl: async () => {
        fetches += 1;
        throw new Error("network must not run");
      },
    });
    const result = await host.testConnectionV2({
      expectedRevision: "sha256:stale",
      selector: { providerId: "provider", model: "model-a" },
    });
    expect(result).toMatchObject({ ok: false, error: { code: "PROFILE_CONFLICT" } });
    expect(vault.resolveCalls).toBe(0);
    expect(fetches).toBe(0);
  });

  it("discovers without holding the writer lock and discards the proposal if the revision changes", async () => {
    const stateHome = temporaryRoot();
    let releaseFetch!: () => void;
    let started!: () => void;
    const startedPromise = new Promise<void>((resolve) => { started = resolve; });
    const waitForRelease = new Promise<void>((resolve) => { releaseFetch = resolve; });
    let fetches = 0;
    const { host, revision } = await seededHost({
      lock: { stateHome, timeoutMs: 2_000, retryDelayMs: 5 },
      fetchImpl: async () => {
        fetches += 1;
        started();
        await waitForRelease;
        return modelsResponse([{ id: "model-b", name: "B" }]);
      },
    });

    const preview = host.previewModels({
      operationId: uuid(2),
      providerId: "provider",
      expectedRevision: revision,
    });
    await startedPromise;
    expect(inspectWriterLock({ stateHome }).locked).toBe(false);

    const mutated = unwrap(await host.transact({
      expectedRevision: revision,
      operation: {
        type: "model.set",
        input: { providerId: "provider", id: "local-only" },
      },
    }));
    expect(mutated.revision).not.toBe(revision);
    releaseFetch();

    const result = await preview;
    expect(result).toMatchObject({ ok: false, error: { code: "PROFILE_CONFLICT" } });
    expect(fetches).toBe(1);

    const apply = await host.applyModels({
      previewId: uuid(99),
      expectedRevision: mutated.revision,
    });
    expect(apply).toMatchObject({ ok: false, error: { code: "MODEL_PREVIEW_NOT_FOUND" } });
  });

  it("applies additions only through a locked CAS write with no network I/O", async () => {
    const stateHome = temporaryRoot();
    let fetches = 0;
    const { host, revision, root } = await seededHost({
      lock: { stateHome, timeoutMs: 2_000, retryDelayMs: 5 },
      fetchImpl: async () => {
        fetches += 1;
        return modelsResponse([
          { id: "model-a", name: "Remote A" },
          { id: "model-b", name: "B" },
          { id: "model-c" },
        ]);
      },
    });

    const namedSeed = unwrap(await host.transact({
      expectedRevision: revision,
      operation: {
        type: "model.set",
        input: { providerId: "provider", id: "keep-name", name: "Local Name", aliases: ["alias-keep"] },
      },
    }));
    const preview = unwrap(await host.previewModels({
      operationId: uuid(3),
      providerId: "provider",
      expectedRevision: namedSeed.revision,
    }));
    expect(preview.added.map((model) => model.id)).toEqual(["model-b", "model-c"]);
    expect(preview.named).toEqual([{ id: "model-a", name: "Remote A" }]);
    expect(fetches).toBe(1);

    fetches = 0;
    const applied = unwrap(await host.applyModels({
      previewId: preview.previewId,
      expectedRevision: namedSeed.revision,
    }));
    expect(fetches).toBe(0);
    expect(inspectWriterLock({ stateHome }).locked).toBe(false);
    expect(applied.revision).not.toBe(namedSeed.revision);
    expect(applied.snapshot.profile.providers[0]?.models.map((model) => ({
      id: model.id,
      name: model.name,
    }))).toEqual([
      { id: "model-a", name: "Remote A" },
      { id: "keep-name", name: "Local Name" },
      { id: "model-b", name: "B" },
      { id: "model-c", name: undefined },
    ]);

    const modelsFile = JSON.parse(fs.readFileSync(
      path.join(root, "providers", "provider", "models.json"),
      "utf8",
    )) as { models: Array<{ id: string; name?: string }> };
    expect(modelsFile.models.find((model) => model.id === "keep-name")?.name).toBe("Local Name");

    const reused = await host.applyModels({
      previewId: preview.previewId,
      expectedRevision: applied.revision,
    });
    expect(reused).toMatchObject({ ok: false, error: { code: "MODEL_PREVIEW_CONSUMED" } });
  });

  it("expires unused proposals after five minutes", async () => {
    let clock = 1_000_000;
    const { host, revision } = await seededHost({
      now: () => clock,
      fetchImpl: async () => modelsResponse([{ id: "model-b", name: "B" }]),
    });
    const preview = unwrap(await host.previewModels({
      operationId: uuid(4),
      providerId: "provider",
      expectedRevision: revision,
    }));
    clock += MODEL_PREVIEW_TTL_MS + 1;
    const expired = await host.applyModels({
      previewId: preview.previewId,
      expectedRevision: revision,
    });
    expect(expired).toMatchObject({ ok: false, error: { code: "MODEL_PREVIEW_EXPIRED" } });
  });

  it("keeps at most eight proposals per host and evicts the oldest", async () => {
    const { host, revision } = await seededHost({
      fetchImpl: async () => modelsResponse([{ id: "model-b", name: "B" }]),
    });
    const previewIds: string[] = [];
    for (let i = 0; i < MODEL_PREVIEW_LIMIT + 1; i++) {
      const preview = unwrap(await host.previewModels({
        operationId: uuid(10 + i),
        providerId: "provider",
        expectedRevision: revision,
      }));
      previewIds.push(preview.previewId);
    }
    const evicted = await host.applyModels({
      previewId: previewIds[0]!,
      expectedRevision: revision,
    });
    expect(evicted).toMatchObject({ ok: false, error: { code: "MODEL_PREVIEW_NOT_FOUND" } });
    const newest = unwrap(await host.applyModels({
      previewId: previewIds[previewIds.length - 1]!,
      expectedRevision: revision,
    }));
    expect(newest.snapshot.profile.providers[0]?.models.some((model) => model.id === "model-b")).toBe(true);
  });

  it("cancels an in-flight preview and does not store a proposal", async () => {
    let releaseFetch!: () => void;
    let started!: () => void;
    const startedPromise = new Promise<void>((resolve) => { started = resolve; });
    const waitForRelease = new Promise<void>((resolve) => { releaseFetch = resolve; });
    const { host, revision } = await seededHost({
      fetchImpl: async (_input, init) => {
        started();
        await waitForRelease;
        if (init?.signal?.aborted) {
          const error = new Error("aborted");
          error.name = "AbortError";
          throw error;
        }
        return modelsResponse([{ id: "model-b", name: "B" }]);
      },
    });

    const preview = host.previewModels({
      operationId: uuid(20),
      providerId: "provider",
      expectedRevision: revision,
    });
    await startedPromise;
    const cancelled = unwrap(await host.cancelPreview({ operationId: uuid(20) }));
    expect(cancelled.cancelled).toBe(true);
    releaseFetch();
    expect(await preview).toMatchObject({
      ok: false,
      error: { code: "MODEL_PREVIEW_CANCELLED" },
    });
  });

  it("rechecks revision after a V2 connection test and leaves V1 refresh unchanged", async () => {
    let releaseFetch!: () => void;
    let started!: () => void;
    const startedPromise = new Promise<void>((resolve) => { started = resolve; });
    const waitForRelease = new Promise<void>((resolve) => { releaseFetch = resolve; });
    let fetches = 0;
    const { host, revision } = await seededHost({
      fetchImpl: async (input) => {
        fetches += 1;
        const url = String(input);
        if (url.includes("/models")) {
          return modelsResponse([{ id: "model-b", name: "B" }]);
        }
        started();
        await waitForRelease;
        return new Response(JSON.stringify({
          choices: [{ message: { content: "pong" }, finish_reason: "stop" }],
        }), { status: 200 });
      },
    });

    const test = host.testConnectionV2({
      expectedRevision: revision,
      selector: { providerId: "provider", model: "model-a" },
    });
    await startedPromise;
    unwrap(await host.transact({
      expectedRevision: revision,
      operation: { type: "model.set", input: { providerId: "provider", id: "other" } },
    }));
    releaseFetch();
    expect(await test).toMatchObject({ ok: false, error: { code: "PROFILE_CONFLICT" } });

    const latest = unwrap(await host.getSnapshot());
    const refreshed = unwrap(await host.transact({
      expectedRevision: latest.revision,
      operation: { type: "models.refresh", providerId: "provider" },
    }));
    expect(refreshed.snapshot.profile.providers[0]?.models.some((model) => model.id === "model-b")).toBe(true);
    expect(fetches).toBeGreaterThanOrEqual(2);
  });

  it("rejects malformed V2 payloads without touching the preview store", async () => {
    const { host } = await seededHost({
      fetchImpl: async () => modelsResponse([]),
    });
    await expect(host.previewModels({
      operationId: "not-a-uuid",
      providerId: "provider",
      expectedRevision: "sha256:x",
    } as never)).resolves.toMatchObject({
      ok: false,
      error: { code: "MANAGER_OPERATION_UNSUPPORTED" },
    });
    await expect(host.applyModels({
      previewId: "also-bad",
      expectedRevision: "sha256:x",
    } as never)).resolves.toMatchObject({
      ok: false,
      error: { code: "MANAGER_OPERATION_UNSUPPORTED" },
    });
    await expect(host.testConnectionV2({
      selector: { default: "chat" },
    } as never)).resolves.toMatchObject({
      ok: false,
      error: { code: "MANAGER_OPERATION_UNSUPPORTED" },
    });
  });
});
