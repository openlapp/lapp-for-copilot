import { describe, expect, it } from "vitest";
import {
  NormalizedChatError,
  createLappClient,
  mapNormalizedToolChoice,
  parseToolArgumentsStrict,
  validateNormalizedChatInput,
  validateNormalizedMessage,
  type AuthConfig,
  type LappProfile,
  type NormalizedChatInput,
  type NormalizedMessage,
} from "../src/index.js";

function profile(protocol: string, auth: AuthConfig = { type: "bearer", secret: "secret" }): LappProfile {
  return {
    global: {
      schemaVersion: "1.0",
      defaults: { chat: { providerId: "p", modelId: "m" } },
    },
    providers: [{
      config: {
        schemaVersion: "1.0",
        id: "p",
        baseUrl: "https://provider.example/v1",
        protocols: [protocol],
        auth,
      },
      models: { schemaVersion: "1.0", models: [{ id: "m", type: "chat" }] },
    }],
  };
}

function json(value: unknown): Response {
  return new Response(JSON.stringify(value), { status: 200 });
}

function sse(events: string[]): Response {
  const encoder = new TextEncoder();
  return new Response(new ReadableStream<Uint8Array>({
    start(controller) {
      controller.enqueue(encoder.encode(events.map((event) => `data: ${event}\n\n`).join("")));
      controller.close();
    },
  }));
}

const PNG = Uint8Array.from([
  0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
  0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01,
  0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0x15, 0xc4, 0x89, 0x00, 0x00, 0x00,
  0x0a, 0x49, 0x44, 0x41, 0x54, 0x78, 0x9c, 0x63, 0x00, 0x01, 0x00, 0x00,
  0x05, 0x00, 0x01, 0x0d, 0x0a, 0x2d, 0xb4, 0x00, 0x00, 0x00, 0x00, 0x49,
  0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82,
]);
const JPEG = Uint8Array.from([0xff, 0xd8, 0xff, 0xd9]);
const GIF = Uint8Array.from([0x47, 0x49, 0x46, 0x38, 0x39, 0x61, 0x00, 0x00]);
const WEBP = Uint8Array.from([
  0x52, 0x49, 0x46, 0x46, 0x00, 0x00, 0x00, 0x00, 0x57, 0x45, 0x42, 0x50,
]);

const PROTOCOLS = [
  "openai-chat-completions",
  "openai-responses",
  "anthropic-messages",
] as const;

function successReply(protocol: string): unknown {
  if (protocol === "openai-chat-completions") {
    return { choices: [{ message: { content: "ok" }, finish_reason: "stop" }] };
  }
  if (protocol === "openai-responses") {
    return { status: "completed", output: [{ type: "message", content: [{ type: "output_text", text: "ok" }] }] };
  }
  return { content: [{ type: "text", text: "ok" }], stop_reason: "end_turn" };
}

function toolReply(protocol: string, args: string): unknown {
  if (protocol === "openai-chat-completions") {
    return {
      choices: [{
        message: {
          content: "calling",
          tool_calls: [{ id: "call_1", type: "function", function: { name: "add", arguments: args } }],
        },
        finish_reason: "tool_calls",
      }],
    };
  }
  if (protocol === "openai-responses") {
    return {
      status: "completed",
      output: [
        { type: "message", content: [{ type: "output_text", text: "calling" }] },
        { type: "function_call", call_id: "call_1", name: "add", arguments: args },
      ],
    };
  }
  return {
    content: [
      { type: "text", text: "calling" },
      { type: "tool_use", id: "call_1", name: "add", input: JSON.parse(args) },
    ],
    stop_reason: "tool_use",
  };
}

async function captureBody(
  protocol: (typeof PROTOCOLS)[number],
  input: NormalizedChatInput,
): Promise<Record<string, unknown>> {
  let body: Record<string, unknown> = {};
  const client = createLappClient({
    profile: profile(protocol),
    fetchImpl: async (_input, init) => {
      body = JSON.parse(String(init?.body)) as Record<string, unknown>;
      return json(successReply(protocol));
    },
  });
  await client.chatNormalized(input);
  return body;
}

describe("normalized chat input validation", () => {
  it("rejects mixed normal and tool-result user content", () => {
    expect(() => validateNormalizedChatInput({
      messages: [{
        role: "user",
        content: [
          { type: "text", text: "hi" },
          { type: "tool-result", toolCallId: "call_1", content: [{ type: "text", text: "3" }] },
        ],
      }],
    })).toThrow(NormalizedChatError);
  });

  it("accepts UTF-8 text/plain, text/markdown, and application/json data", () => {
    const encoder = new TextEncoder();
    expect(() => validateNormalizedChatInput({
      messages: [{
        role: "user",
        content: [
          { type: "text", text: "hello" },
          { type: "data", mediaType: "text/plain", data: encoder.encode("plain") },
          { type: "data", mediaType: "text/markdown", data: encoder.encode("# md") },
          { type: "data", mediaType: "application/json", data: encoder.encode("{\"a\":1}") },
        ],
      }],
    })).not.toThrow();
  });

  it("rejects invalid UTF-8 data and non-JSON application/json", () => {
    expect(() => validateNormalizedChatInput({
      messages: [{
        role: "user",
        content: [{ type: "data", mediaType: "text/plain", data: Uint8Array.from([0xff, 0xfe]) }],
      }],
    })).toThrow(/UTF-8/);
    expect(() => validateNormalizedChatInput({
      messages: [{
        role: "user",
        content: [{ type: "data", mediaType: "application/json", data: new TextEncoder().encode("not-json") }],
      }],
    })).toThrow(/JSON/);
  });

  it("accepts PNG, JPEG, WebP, and GIF image bytes and rejects other payloads", () => {
    for (const [mediaType, data] of [
      ["image/png", PNG],
      ["image/jpeg", JPEG],
      ["image/webp", WEBP],
      ["image/gif", GIF],
    ] as const) {
      expect(() => validateNormalizedChatInput({
        messages: [{ role: "user", content: [{ type: "image", mediaType, data }] }],
      })).not.toThrow();
    }
    expect(() => validateNormalizedChatInput({
      messages: [{
        role: "user",
        content: [{ type: "image", mediaType: "image/png", data: new TextEncoder().encode("nope") }],
      }],
    })).toThrow(/media type/);
  });

  it("rejects assistant data, tool-result, and text after the first tool call", () => {
    const toolCall = {
      type: "tool-call" as const,
      id: "call_1",
      name: "add",
      arguments: { a: 1 },
    };
    expect(() => validateNormalizedMessage({
      role: "assistant",
      content: [{ type: "data", mediaType: "text/plain", data: new TextEncoder().encode("x") }],
    } as unknown as NormalizedMessage)).toThrow(/data/);
    expect(() => validateNormalizedChatInput({
      messages: [{
        role: "assistant",
        content: [
          { type: "text", text: "before" },
          toolCall,
          { type: "text", text: "after" },
        ],
      }],
    })).toThrow(/after the first tool call/);
  });

  it("rejects image tool results", () => {
    expect(() => validateNormalizedChatInput({
      messages: [{
        role: "user",
        content: [{
          type: "tool-result",
          toolCallId: "call_1",
          content: [{ type: "image", mediaType: "image/png", data: PNG }],
        }],
      } as unknown as NormalizedMessage],
    })).toThrow(/image tool results/);
  });

  it("requires tool-call arguments to be a JSON object", () => {
    expect(() => parseToolArgumentsStrict("{")).toThrow(NormalizedChatError);
    expect(() => parseToolArgumentsStrict("[1]")).toThrow(NormalizedChatError);
    expect(() => parseToolArgumentsStrict("\"x\"")).toThrow(NormalizedChatError);
    expect(parseToolArgumentsStrict("{\"a\":1}")).toEqual({ a: 1 });
  });
});

describe("normalized protocol mapping", () => {
  const encoder = new TextEncoder();
  const userInput: NormalizedChatInput = {
    messages: [
      { role: "system", content: [{ type: "text", text: "sys" }] },
      {
        role: "user",
        content: [
          { type: "text", text: "look" },
          { type: "data", mediaType: "application/json", data: encoder.encode("{\"k\":true}") },
          { type: "image", mediaType: "image/png", data: PNG },
        ],
      },
    ],
    tools: [{ name: "add", parameters: { type: "object" } }],
    toolChoice: { type: "named", name: "add" },
  };

  it.each(PROTOCOLS)("maps text, JSON data, and PNG input for %s", async (protocol) => {
    const body = await captureBody(protocol, userInput);
    const serialized = JSON.stringify(body);
    expect(serialized).toContain("look");
    expect(serialized).toContain("k");
    expect(serialized).toMatch(/\{\\"k\\":true\}/);
    expect(serialized).toContain(Buffer.from(PNG).toString("base64"));
    if (protocol === "openai-chat-completions") {
      expect(body.tool_choice).toEqual({ type: "function", function: { name: "add" } });
      const messages = body.messages as Array<Record<string, unknown>>;
      expect(messages[0]).toMatchObject({ role: "system", content: "sys" });
      expect(messages[1]?.role).toBe("user");
    }
    if (protocol === "openai-responses") {
      expect(body.tool_choice).toEqual({ type: "function", name: "add" });
      expect(body.instructions).toBe("sys");
      const input = body.input as Array<Record<string, unknown>>;
      expect(input[0]?.role).toBe("user");
    }
    if (protocol === "anthropic-messages") {
      expect(body.tool_choice).toEqual({ type: "tool", name: "add" });
      expect(body.system).toBe("sys");
    }
  });

  it.each(PROTOCOLS)("maps a pure tool-result user collection for %s", async (protocol) => {
    const body = await captureBody(protocol, {
      messages: [{
        role: "user",
        content: [{
          type: "tool-result",
          toolCallId: "call_1",
          content: [
            { type: "text", text: "3" },
            { type: "data", mediaType: "text/plain", data: encoder.encode(" extra") },
          ],
        }],
      }],
    });
    const serialized = JSON.stringify(body);
    expect(serialized).toContain("3 extra");
    if (protocol === "openai-chat-completions") {
      expect(body.messages).toEqual([{ role: "tool", tool_call_id: "call_1", content: "3 extra" }]);
    }
    if (protocol === "openai-responses") {
      expect(body.input).toEqual([{ type: "function_call_output", call_id: "call_1", output: "3 extra" }]);
    }
    if (protocol === "anthropic-messages") {
      expect(body.messages).toEqual([{
        role: "user",
        content: [{ type: "tool_result", tool_use_id: "call_1", content: "3 extra" }],
      }]);
    }
  });

  it("maps normalized tool choice consistently", () => {
    expect(mapNormalizedToolChoice("auto", "openai-chat-completions")).toBe("auto");
    expect(mapNormalizedToolChoice("required", "openai-responses")).toBe("required");
    expect(mapNormalizedToolChoice("none", "openai-chat-completions")).toBe("none");
    expect(mapNormalizedToolChoice("auto", "anthropic-messages")).toEqual({ type: "auto" });
    expect(mapNormalizedToolChoice("required", "anthropic-messages")).toEqual({ type: "any" });
    expect(mapNormalizedToolChoice("none", "anthropic-messages")).toEqual({ type: "none" });
    expect(mapNormalizedToolChoice({ type: "named", name: "add" }, "anthropic-messages"))
      .toEqual({ type: "tool", name: "add" });
  });
});

describe("normalized protocol responses", () => {
  it.each(PROTOCOLS)("parses text-then-tool-call output for %s", async (protocol) => {
    const client = createLappClient({
      profile: profile(protocol),
      fetchImpl: async () => json(toolReply(protocol, "{\"a\":1,\"b\":2}")),
    });
    const response = await client.chatNormalized({
      messages: [{ role: "user", content: [{ type: "text", text: "add" }] }],
    });
    expect(response.text).toBe("calling");
    expect(response.parts).toEqual([
      { type: "text", text: "calling" },
      { type: "tool-call", id: "call_1", name: "add", arguments: { a: 1, b: 2 } },
    ]);
  });

  it.each(PROTOCOLS)("fails invalid tool-call argument objects for %s", async (protocol) => {
    if (protocol === "anthropic-messages") {
      const client = createLappClient({
        profile: profile(protocol),
        fetchImpl: async () => json({
          content: [{ type: "tool_use", id: "call_1", name: "add", input: [1, 2] }],
        }),
      });
      await expect(client.chatNormalized({
        messages: [{ role: "user", content: [{ type: "text", text: "add" }] }],
      })).rejects.toThrow(/JSON object/);
      return;
    }
    const client = createLappClient({
      profile: profile(protocol),
      fetchImpl: async () => json(toolReply(protocol, "[1,2]")),
    });
    await expect(client.chatNormalized({
      messages: [{ role: "user", content: [{ type: "text", text: "add" }] }],
    })).rejects.toThrow(/JSON object/);
  });

  it("rejects text after the first tool call in Anthropic output", async () => {
    const client = createLappClient({
      profile: profile("anthropic-messages"),
      fetchImpl: async () => json({
        content: [
          { type: "text", text: "before" },
          { type: "tool_use", id: "call_1", name: "add", input: { a: 1 } },
          { type: "text", text: "after" },
        ],
      }),
    });
    await expect(client.chatNormalized({
      messages: [{ role: "user", content: [{ type: "text", text: "add" }] }],
    })).rejects.toThrow(/after the first tool call/);
  });

  it.each(PROTOCOLS)("rejects image or tool-result assistant output for %s", async (protocol) => {
    const raw = protocol === "openai-chat-completions"
      ? { choices: [{ message: { content: [{ type: "image_url", image_url: { url: "x" } }] } }] }
      : protocol === "openai-responses"
        ? { status: "completed", output: [{ type: "input_image", image_url: "x" }] }
        : { content: [{ type: "image", source: { type: "base64", media_type: "image/png", data: "xx" } }] };
    const client = createLappClient({
      profile: profile(protocol),
      fetchImpl: async () => json(raw),
    });
    await expect(client.chatNormalized({
      messages: [{ role: "user", content: [{ type: "text", text: "hi" }] }],
    })).rejects.toThrow(/data, image, or tool-result/);
  });

  it("fails streamed non-object arguments instead of becoming {}", async () => {
    const client = createLappClient({
      profile: profile("openai-chat-completions"),
      fetchImpl: async () => sse([
        JSON.stringify({
          choices: [{
            delta: { tool_calls: [{ index: 0, id: "call_1", function: { name: "add", arguments: "[" } }] },
            finish_reason: "tool_calls",
          }],
        }),
        "[DONE]",
      ]),
    });
    await expect(async () => {
      for await (const _event of client.streamNormalized({
        messages: [{ role: "user", content: [{ type: "text", text: "add" }] }],
      })) {
        // consume
      }
    }).rejects.toThrow(/JSON object/);

    const v1Events = [];
    const v1 = createLappClient({
      profile: profile("openai-chat-completions"),
      fetchImpl: async () => sse([
        JSON.stringify({
          choices: [{
            delta: { tool_calls: [{ index: 0, id: "call_1", function: { name: "add", arguments: "[" } }] },
            finish_reason: "tool_calls",
          }],
        }),
        "[DONE]",
      ]),
    });
    for await (const event of v1.stream({ messages: [{ role: "user", content: "add" }] })) {
      v1Events.push(event);
    }
    expect(v1Events.filter((event) => event.kind === "tool-call")).toEqual([
      { kind: "tool-call", id: "call_1", name: "add", arguments: "[" },
    ]);
  });
});
