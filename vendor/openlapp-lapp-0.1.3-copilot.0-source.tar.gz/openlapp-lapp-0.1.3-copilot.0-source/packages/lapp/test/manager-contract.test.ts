import fs from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";
import {
  LAPP_MANAGER_BRIDGE_PROTOCOL_VERSION,
  LAPP_MANAGER_BRIDGE_PROTOCOL_VERSION_V2,
  type ManagerPreviewModelsView,
  type ManagerResult,
  type ManagerSnapshot,
} from "../src/manager/contract.js";

describe("browser-safe manager contract", () => {
  it("is structured-clone-safe and has a stable protocol version", () => {
    const value: ManagerResult<ManagerSnapshot> = {
      ok: true,
      value: {
        revision: "sha256:test",
        profile: { providers: [] },
        diagnostics: [],
      },
    };
    const preview: ManagerPreviewModelsView = {
      previewId: "00000000-0000-4000-8000-000000000001",
      operationId: "00000000-0000-4000-8000-000000000002",
      providerId: "provider",
      added: [{ id: "model-b", name: "B" }],
      named: [{ id: "model-a", name: "A" }],
      expiresAt: "2026-01-01T00:05:00.000Z",
    };
    expect(LAPP_MANAGER_BRIDGE_PROTOCOL_VERSION).toBe(1);
    expect(LAPP_MANAGER_BRIDGE_PROTOCOL_VERSION_V2).toBe(2);
    expect(structuredClone(value)).toEqual(value);
    expect(structuredClone(preview)).toEqual(preview);
  });

  it("contains no Node or native runtime imports", () => {
    const source = fs.readFileSync(
      fileURLToPath(new URL("../src/manager/contract.ts", import.meta.url)),
      "utf8",
    );
    expect(source).not.toMatch(/from\s+["']node:/);
    expect(source).not.toContain("@napi-rs/keyring");
    expect(source.match(/^import\s+(?!type\b)/gm) ?? []).toHaveLength(0);
  });
});
