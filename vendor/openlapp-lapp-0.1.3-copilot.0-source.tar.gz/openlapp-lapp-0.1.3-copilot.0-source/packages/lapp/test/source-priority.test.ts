import { describe, expect, it } from "vitest";
import {
  compareSourcePriority,
  listModelCandidates,
  resolveModelCandidates,
  createProfile,
  upsertAuthSource,
  upsertProvider,
} from "../src/index.js";

describe("registry source priority", () => {
  it("sorts lower explicit priorities first, then omitted priorities by stable ID", () => {
    const sources = [
      { id: "z-default" },
      { id: "provider-b", priority: 20 },
      { id: "provider-z", priority: 10 },
      { id: "provider-a", priority: 10 },
      { id: "a-default" },
    ];

    expect(sources.sort(compareSourcePriority).map(({ id }) => id)).toEqual([
      "provider-a",
      "provider-z",
      "provider-b",
      "a-default",
      "z-default",
    ]);
  });

  it("is reflexive and antisymmetric when explicit priorities are equal", () => {
    const a = { id: "a", priority: 10 };
    const z = { id: "z", priority: 10 };

    expect(compareSourcePriority(a, a)).toBe(0);
    expect(compareSourcePriority(a, z)).toBe(-1);
    expect(compareSourcePriority(z, a)).toBe(1);
    expect(compareSourcePriority(a, z)).toBe(-compareSourcePriority(z, a));
  });

  it("preserves priority independently for provider and Auth sources", () => {
    let profile = createProfile({ rootDir: "C:/lapp-priority-test" });
    profile = upsertProvider(profile, {
      id: "provider",
      priority: 12,
      baseUrl: "https://example.test/v1",
      protocols: ["openai-chat-completions"],
      auth: { type: "none" },
    });
    profile = upsertAuthSource(profile, {
      id: "subscription",
      priority: 3,
      driver: "openai-codex",
      protocols: ["openai-responses"],
    });

    expect(profile.providers[0]?.config.priority).toBe(12);
    expect(profile.providers[0]?.models.models).toEqual([]);
    expect(profile.auth?.[0]?.config.priority).toBe(3);
    expect(JSON.parse(JSON.stringify(profile)).auth[0].config.priority).toBe(3);
  });
});

it("lists and resolves candidates with Rust-equivalent alias and protocol semantics", () => {
  const profile = {
    providers: [{
      config: { schemaVersion: "1.0" as const, id: "later", priority: 20, baseUrl: "https://later.test/v1", protocols: ["openai-chat-completions"], auth: { type: "none" as const } },
      models: { schemaVersion: "1.0" as const, models: [{ id: "shared", aliases: ["alias"] }] },
    }, {
      config: { schemaVersion: "1.0" as const, id: "disabled", priority: 1, enabled: false, baseUrl: "https://disabled.test/v1", protocols: ["openai-chat-completions"], auth: { type: "none" as const } },
      models: { schemaVersion: "1.0" as const, models: [{ id: "shared" }] },
    }],
    auth: [{
      config: { schemaVersion: "1.1" as const, id: "first", priority: 10, driver: "openai-codex", protocols: ["openai-responses", "openai-chat-completions"] },
      models: { schemaVersion: "1.0" as const, models: [{ id: "shared", aliases: ["alias"], protocols: ["openai-responses"] }] },
    }],
  };
  const candidates = listModelCandidates(profile);
  expect(candidates).toHaveLength(2);
  expect(candidates[0]).toMatchObject({ source: "auth", authId: "first", protocols: ["openai-responses"] });
  expect(resolveModelCandidates(profile, "alias")).toHaveLength(2);
});
