/** Source metadata used by gateway/runtime selection. */
export interface SourcePriorityCandidate {
  id: string;
  priority?: number;
}

/**
 * Compare registry sources by optional priority, then stable source ID.
 *
 * Explicit priorities sort before omitted values; lower values are preferred.
 * This helper does not select an LAPP protocol adapter.
 */
export function compareSourcePriority(
  left: SourcePriorityCandidate,
  right: SourcePriorityCandidate,
): number {
  if (left.priority !== undefined && right.priority !== undefined) {
    if (left.priority < right.priority) return -1;
    if (left.priority > right.priority) return 1;
  } else {
    if (left.priority !== undefined) return -1;
    if (right.priority !== undefined) return 1;
  }
  if (left.id < right.id) return -1;
  if (left.id > right.id) return 1;
  return 0;
}
