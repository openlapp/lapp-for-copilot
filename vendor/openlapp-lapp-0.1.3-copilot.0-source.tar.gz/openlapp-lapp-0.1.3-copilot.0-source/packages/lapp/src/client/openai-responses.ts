/**
 * OpenAI Responses API adapter.
 *
 * Maps a simple chat input to the Responses API input shape and POSTs
 * `{baseUrl}/responses`. The Responses API uses an `input` field (string or
 * array of input items) rather than `messages`.
 */

import type {
  AdapterContext,
  AdapterRequest,
  ChatInput,
  LappResponse,
  LappStreamEventUnion,
  ParsedToolCall,
  ProtocolAdapter,
} from "./adapter.js";
import { assertSafeExtra, isRecord, parseToolArguments } from "./adapter.js";
import { parseSse } from "./sse.js";
import { appendUrlPath, buildAuthHeaders } from "./http.js";
import { parseUsageInteger } from "./usage.js";

const INVALID_RESPONSE = "invalid openai-responses response";

function buildInputItems(messages: ChatInput["messages"]): Array<Record<string, unknown>> {
  return messages.flatMap((m): Array<Record<string, unknown>> => {
    if (m.role === "system") {
      // System messages are handled separately as instructions.
      return [];
    }
    if (m.role === "tool") {
      if (!m.toolCallId) throw new Error("tool messages require toolCallId for openai-responses");
      return [{
        type: "function_call_output",
        call_id: m.toolCallId,
        output: m.content,
      }];
    }
    if (m.role === "assistant" && m.toolCalls?.length) {
      return [
        ...(m.content ? [{ role: "assistant", content: m.content }] : []),
        ...m.toolCalls.map((tc) => ({
          type: "function_call",
          call_id: tc.id,
          name: tc.name,
          arguments: tc.arguments,
        })),
      ];
    }
    return [{ role: m.role, content: m.content }];
  });
}

function parseToolCalls(toolCalls: unknown): ParsedToolCall[] | undefined {
  if (!Array.isArray(toolCalls)) return undefined;
  const out: ParsedToolCall[] = [];
  for (const tc of toolCalls) {
    const rawArgs = typeof tc.function?.arguments === "string" ? tc.function.arguments : "";
    const parsed = parseToolArguments(rawArgs);
    out.push({
      id: String(tc.id ?? ""),
      name: String(tc.function?.name ?? ""),
      ...parsed,
    });
  }
  return out.length ? out : undefined;
}

export const openaiResponsesAdapter: ProtocolAdapter = {
  protocol: "openai-responses",

  buildRequest(input: ChatInput, ctx: AdapterContext): AdapterRequest {
    assertSafeExtra(input.extra);
    const systemMessages = input.messages.filter((m) => m.role === "system");
    const body: Record<string, unknown> = {
      model: ctx.model,
      input: buildInputItems(input.messages),
      ...(systemMessages.length > 0
        ? { instructions: systemMessages.map((m) => m.content).join("\n\n") }
        : {}),
      ...(typeof input.temperature === "number" ? { temperature: input.temperature } : {}),
      ...(typeof input.maxTokens === "number" ? { max_output_tokens: input.maxTokens } : {}),
      ...(input.stopSequences?.length ? { stop: input.stopSequences } : {}),
      ...(typeof input.parallelToolCalls === "boolean" ? { parallel_tool_calls: input.parallelToolCalls } : {}),
      ...(input.reasoning ? { reasoning: input.reasoning } : {}),
      ...(input.promptCacheKey ? { prompt_cache_key: input.promptCacheKey } : {}),
      ...(input.promptCacheRetention ? { prompt_cache_retention: input.promptCacheRetention } : {}),
      ...(input.tools?.length ? {
        tools: input.tools.map((t) => ({ type: "function", name: t.name, description: t.description, parameters: t.parameters })),
        ...(input.toolChoice !== undefined ? { tool_choice: input.toolChoice } : {}),
      } : {}),
      ...(input.stream ? { stream: true } : {}),
      ...(input.extra ?? {}),
    };
    return {
      url: appendUrlPath(ctx.baseUrl, "/responses"),
      method: "POST",
      headers: buildAuthHeaders(ctx),
      body,
      stream: input.stream,
    };
  },

  parseResponse(raw: unknown, ctx: AdapterContext): LappResponse {
    if (
      !isRecord(raw)
      || typeof raw.status !== "string"
      || !Array.isArray(raw.output)
      || raw.output.some((item) => !isRecord(item))
    ) {
      throw new Error("invalid openai-responses response");
    }
    for (const item of raw.output) {
      if (typeof item.type !== "string") {
        throw new Error("invalid openai-responses response");
      }
      if (item.content !== undefined && (
        !Array.isArray(item.content)
        || item.content.some((content: unknown) => (
          !isRecord(content)
          || typeof content.type !== "string"
          || (content.type === "output_text" && typeof content.text !== "string")
        ))
      )) {
        throw new Error("invalid openai-responses response");
      }
      if (item.type === "function_call" && (
        typeof item.call_id !== "string"
        || typeof item.name !== "string"
        || typeof item.arguments !== "string"
      )) {
        throw new Error("invalid openai-responses response");
      }
    }
    if (raw.model !== undefined && typeof raw.model !== "string") {
      throw new Error("invalid openai-responses response");
    }
    if (raw.usage !== undefined && (
      !isRecord(raw.usage)
      || (raw.usage.input_tokens_details !== undefined && !isRecord(raw.usage.input_tokens_details))
      || (raw.usage.output_tokens_details !== undefined && !isRecord(raw.usage.output_tokens_details))
    )) {
      throw new Error(INVALID_RESPONSE);
    }
    const r = raw as {
      output?: Array<{ type?: string; content?: Array<{ type?: string; text?: string }>; call_id?: string; name?: string; arguments?: string }>;
      output_text?: string;
      model?: string;
      status?: string;
      usage?: {
        input_tokens?: number; output_tokens?: number; total_tokens?: number;
        input_tokens_details?: { cached_tokens?: number };
        output_tokens_details?: { reasoning_tokens?: number };
      };
    };
    let text = r.output_text ?? "";
    if (!text && Array.isArray(r.output)) {
      text = r.output
        .flatMap((o) => o.content ?? [])
        .filter((c) => c.type === "output_text" || c.type === "message_output_text")
        .map((c) => c.text ?? "")
        .join("");
    }
    const toolCalls: ParsedToolCall[] | undefined = parseToolCalls(
      r.output?.filter((o) => o.type === "function_call").map((o) => ({
        id: o.call_id ?? "",
        type: "function",
        function: { name: o.name ?? "", arguments: o.arguments ?? "" },
      })),
    );
    return {
      text,
      provider: ctx.providerId,
      model: r.model ?? ctx.model,
      protocol: ctx.protocol,
      finishReason: r.status,
      toolCalls,
      usage: r.usage
        ? {
            inputTokens: parseUsageInteger(r.usage.input_tokens, INVALID_RESPONSE),
            outputTokens: parseUsageInteger(r.usage.output_tokens, INVALID_RESPONSE),
            totalTokens: parseUsageInteger(r.usage.total_tokens, INVALID_RESPONSE),
            cacheReadInputTokens: parseUsageInteger(r.usage.input_tokens_details?.cached_tokens, INVALID_RESPONSE),
            reasoningTokens: parseUsageInteger(r.usage.output_tokens_details?.reasoning_tokens, INVALID_RESPONSE),
          }
        : undefined,
      raw,
    };
  },

  async *parseStream(body: ReadableStream<Uint8Array>, ctx: AdapterContext): AsyncIterable<LappStreamEventUnion> {
    const toolCallAcc: Record<string, { id: string; name: string; args: string }> = {};
    let flushed = false;

    for await (const ev of parseSse(body)) {
      if (ev.data === "[DONE]") continue;
      let parsed: unknown;
      try {
        parsed = JSON.parse(ev.data);
      } catch {
        yield { kind: "error", message: `invalid JSON in stream: ${ev.data}` };
        continue;
      }
      const chunk = parsed as {
        type?: string;
        delta?: string;
        error?: { message?: string };
        item?: { type?: string; id?: string; call_id?: string; name?: string; arguments?: string };
        response?: {
          status?: string;
          error?: { message?: string };
          usage?: {
            input_tokens?: number; output_tokens?: number; total_tokens?: number;
            input_tokens_details?: { cached_tokens?: number };
            output_tokens_details?: { reasoning_tokens?: number };
          };
        };
      };

      if (chunk.type === "response.output_text.delta" && typeof chunk.delta === "string") {
        yield { kind: "delta", text: chunk.delta };
      }

      if (chunk.type === "response.output_item.added" && chunk.item?.type === "function_call") {
        // Responses-API: deltas correlate via top-level `item_id`, which equals
        // `item.id` (the function_call output item id, e.g. "fc_123"), NOT
        // `item.call_id` ("call_123"). Key the accumulator by `item.id` so
        // the subsequent `function_call_arguments.delta` lookup hits.
        const itemId = chunk.item.id ?? chunk.item.call_id ?? "";
        toolCallAcc[itemId] = {
          id: chunk.item.call_id ?? "",
          name: chunk.item.name ?? "",
          args: chunk.item.arguments ?? "",
        };
      }

      if (chunk.type === "response.function_call_arguments.delta") {
        // The Responses API correlates delta events via the top-level  field,
        // not `chunk.item.call_id` (which is only present on -output-item.added).
        const id = (chunk as unknown as { item_id?: string }).item_id ?? "";
        if (toolCallAcc[id] && typeof chunk.delta === "string") {
          toolCallAcc[id].args += chunk.delta;
        }
      }

      if (chunk.type === "response.completed" && chunk.response) {
        for (const tc of Object.values(toolCallAcc)) {
          yield { kind: "tool-call", id: tc.id, name: tc.name, arguments: tc.args };
        }
        // Mark flushed so the post-loop truncated-stream flush does not
        // re-emit the same tool calls on a normal completion.
        flushed = true;
        if (chunk.response.usage) {
          yield {
            kind: "usage",
            inputTokens: parseUsageInteger(chunk.response.usage.input_tokens, INVALID_RESPONSE),
            outputTokens: parseUsageInteger(chunk.response.usage.output_tokens, INVALID_RESPONSE),
            totalTokens: parseUsageInteger(chunk.response.usage.total_tokens, INVALID_RESPONSE),
            cacheReadInputTokens: parseUsageInteger(chunk.response.usage.input_tokens_details?.cached_tokens, INVALID_RESPONSE),
            reasoningTokens: parseUsageInteger(chunk.response.usage.output_tokens_details?.reasoning_tokens, INVALID_RESPONSE),
          };
        }
        yield { kind: "finish", reason: chunk.response.status ?? "completed" };
      }

      if (chunk.type === "response.failed" || chunk.type === "error") {
        yield {
          kind: "error",
          message: chunk.response?.error?.message ?? chunk.error?.message ?? "response stream failed",
        };
      }
    }

    // In case the provider never sent response.completed (truncated stream),
    // flush any accumulated tool calls. Gated by `flushed` so a normal
    // completion (which already flushed inside the loop) does not re-emit.
    if (!flushed && Object.keys(toolCallAcc).length > 0) {
      for (const tc of Object.values(toolCallAcc)) {
        yield { kind: "tool-call", id: tc.id, name: tc.name, arguments: tc.args };
      }
    }
  },
};
