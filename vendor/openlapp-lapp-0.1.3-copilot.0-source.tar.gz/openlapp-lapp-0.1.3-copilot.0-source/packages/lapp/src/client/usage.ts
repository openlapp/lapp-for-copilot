/** Parse one exact token counter shared by every protocol adapter. */
export function parseUsageInteger(value: unknown, invalidMessage: string): number | undefined {
  if (value === undefined) return undefined;
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < 0) {
    throw new Error(invalidMessage);
  }
  return value;
}

/** Add two token counters without crossing the I-JSON safe-integer boundary. */
export function addUsageIntegers(
  left: number | undefined,
  right: number | undefined,
  invalidMessage: string,
): number | undefined {
  if (left === undefined || right === undefined) return undefined;
  return parseUsageInteger(left + right, invalidMessage);
}
