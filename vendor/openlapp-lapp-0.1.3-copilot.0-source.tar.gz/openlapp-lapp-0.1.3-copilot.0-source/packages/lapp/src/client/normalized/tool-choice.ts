import type { NormalizedToolChoice } from "./types.js";

export function mapNormalizedToolChoice(
  choice: NormalizedToolChoice | undefined,
  protocol: string,
): unknown {
  if (choice === undefined) return undefined;
  if (protocol === "anthropic-messages") {
    if (choice === "auto") return { type: "auto" };
    if (choice === "required") return { type: "any" };
    if (choice === "none") return { type: "none" };
    return { type: "tool", name: choice.name };
  }
  if (protocol === "openai-responses") {
    if (typeof choice === "string") return choice;
    return { type: "function", name: choice.name };
  }
  if (typeof choice === "string") return choice;
  return { type: "function", function: { name: choice.name } };
}
