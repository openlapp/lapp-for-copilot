import type { AdapterContext, AdapterRequest, ChatInput, ProtocolAdapter } from "../adapter.js";
import { joinTextAndData } from "./validate.js";
import { mapNormalizedToolChoice } from "./tool-choice.js";
import type {
  NormalizedAssistantPart,
  NormalizedChatInput,
  NormalizedImagePart,
  NormalizedMessage,
  NormalizedToolResultPart,
  NormalizedUserNormalPart,
} from "./types.js";

function toBase64(data: Uint8Array): string {
  return Buffer.from(data).toString("base64");
}

function imageDataUrl(part: NormalizedImagePart): string {
  return `data:${part.mediaType};base64,${toBase64(part.data)}`;
}

function toolResultText(part: NormalizedToolResultPart): string {
  return joinTextAndData(part.content);
}

function openaiChatContent(parts: NormalizedUserNormalPart[]): string | Array<Record<string, unknown>> {
  if (parts.length === 1 && parts[0]!.type === "text") return parts[0]!.text;
  return parts.map((part) => {
    if (part.type === "image") {
      return { type: "image_url", image_url: { url: imageDataUrl(part) } };
    }
    return { type: "text", text: part.type === "text" ? part.text : joinTextAndData([part]) };
  });
}

function openaiChatMessages(messages: NormalizedMessage[]): Array<Record<string, unknown>> {
  return messages.flatMap((message) => {
    if (message.role === "system") {
      return [{ role: "system", content: joinTextAndData(message.content) }];
    }
    if (message.role === "user") {
      if (message.content.every((part) => part.type === "tool-result")) {
        return (message.content as NormalizedToolResultPart[]).map((part) => ({
          role: "tool",
          tool_call_id: part.toolCallId,
          content: toolResultText(part),
        }));
      }
      return [{ role: "user", content: openaiChatContent(message.content as NormalizedUserNormalPart[]) }];
    }
    const text = message.content
      .filter((part): part is Extract<NormalizedAssistantPart, { type: "text" }> => part.type === "text")
      .map((part) => part.text)
      .join("");
    const toolCalls = message.content.filter((part) => part.type === "tool-call");
    if (toolCalls.length === 0) return [{ role: "assistant", content: text }];
    return [{
      role: "assistant",
      content: text,
      tool_calls: toolCalls.map((part) => ({
        id: part.id,
        type: "function",
        function: { name: part.name, arguments: JSON.stringify(part.arguments) },
      })),
    }];
  });
}

function openaiResponsesItems(messages: NormalizedMessage[]): Array<Record<string, unknown>> {
  return messages.flatMap((message): Array<Record<string, unknown>> => {
    if (message.role === "system") return [];
    if (message.role === "user") {
      if (message.content.every((part) => part.type === "tool-result")) {
        return (message.content as NormalizedToolResultPart[]).map((part) => ({
          type: "function_call_output",
          call_id: part.toolCallId,
          output: toolResultText(part),
        }));
      }
      const parts = message.content as NormalizedUserNormalPart[];
      return [{
        role: "user",
        content: parts.map((part) => (
          part.type === "image"
            ? { type: "input_image", image_url: imageDataUrl(part) }
            : { type: "input_text", text: part.type === "text" ? part.text : joinTextAndData([part]) }
        )),
      }];
    }
    const text = message.content
      .filter((part): part is Extract<NormalizedAssistantPart, { type: "text" }> => part.type === "text")
      .map((part) => part.text)
      .join("");
    const toolCalls = message.content.filter((part) => part.type === "tool-call");
    return [
      ...(text ? [{ role: "assistant", content: text }] : []),
      ...toolCalls.map((part) => ({
        type: "function_call",
        call_id: part.id,
        name: part.name,
        arguments: JSON.stringify(part.arguments),
      })),
    ];
  });
}

function anthropicMessages(messages: NormalizedMessage[]): Array<Record<string, unknown>> {
  return messages.flatMap((message) => {
    if (message.role === "system") return [];
    if (message.role === "user") {
      if (message.content.every((part) => part.type === "tool-result")) {
        return [{
          role: "user",
          content: (message.content as NormalizedToolResultPart[]).map((part) => ({
            type: "tool_result",
            tool_use_id: part.toolCallId,
            content: toolResultText(part),
          })),
        }];
      }
      return [{
        role: "user",
        content: (message.content as NormalizedUserNormalPart[]).map((part) => (
          part.type === "image"
            ? {
                type: "image",
                source: {
                  type: "base64",
                  media_type: part.mediaType,
                  data: toBase64(part.data),
                },
              }
            : { type: "text", text: part.type === "text" ? part.text : joinTextAndData([part]) }
        )),
      }];
    }
    const blocks: Array<Record<string, unknown>> = [];
    for (const part of message.content) {
      if (part.type === "text" && part.text.length > 0) {
        blocks.push({ type: "text", text: part.text });
      }
      if (part.type === "tool-call") {
        blocks.push({ type: "tool_use", id: part.id, name: part.name, input: part.arguments });
      }
    }
    return [{ role: "assistant", content: blocks }];
  });
}

function applyMappedBody(protocol: string, body: Record<string, unknown>, input: NormalizedChatInput): void {
  const systemText = input.messages
    .filter((message) => message.role === "system")
    .map((message) => joinTextAndData(message.content))
    .join("\n\n");
  if (protocol === "openai-chat-completions") {
    body.messages = openaiChatMessages(input.messages);
    return;
  }
  if (protocol === "openai-responses") {
    body.input = openaiResponsesItems(input.messages);
    if (systemText) body.instructions = systemText;
    else delete body.instructions;
    return;
  }
  if (protocol === "anthropic-messages") {
    body.messages = anthropicMessages(input.messages);
    if (systemText) body.system = systemText;
    else delete body.system;
    return;
  }
  throw new Error(`unsupported protocol: ${protocol}`);
}

export function buildNormalizedRequest(
  adapter: ProtocolAdapter,
  input: NormalizedChatInput,
  ctx: AdapterContext,
): AdapterRequest {
  const placeholder: ChatInput = {
    messages: [{ role: "user", content: " " }],
    ...(input.temperature !== undefined ? { temperature: input.temperature } : {}),
    ...(input.maxTokens !== undefined ? { maxTokens: input.maxTokens } : {}),
    ...(input.stopSequences !== undefined ? { stopSequences: input.stopSequences } : {}),
    ...(input.parallelToolCalls !== undefined ? { parallelToolCalls: input.parallelToolCalls } : {}),
    ...(input.reasoning !== undefined ? { reasoning: input.reasoning } : {}),
    ...(input.promptCacheKey !== undefined ? { promptCacheKey: input.promptCacheKey } : {}),
    ...(input.promptCacheRetention !== undefined ? { promptCacheRetention: input.promptCacheRetention } : {}),
    ...(input.extra !== undefined ? { extra: input.extra } : {}),
    ...(input.stream !== undefined ? { stream: input.stream } : {}),
    ...(input.tools !== undefined ? { tools: input.tools } : {}),
    ...(input.toolChoice !== undefined
      ? { toolChoice: mapNormalizedToolChoice(input.toolChoice, adapter.protocol) }
      : {}),
    ...(input.signal !== undefined ? { signal: input.signal } : {}),
  };
  const request = adapter.buildRequest(placeholder, ctx);
  applyMappedBody(adapter.protocol, request.body as Record<string, unknown>, input);
  return request;
}
