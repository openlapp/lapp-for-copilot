import type { ToolDefinition } from "../adapter.js";

export const NORMALIZED_TEXT_MEDIA_TYPES = [
  "text/plain",
  "text/markdown",
  "application/json",
] as const;

export const NORMALIZED_IMAGE_MEDIA_TYPES = [
  "image/png",
  "image/jpeg",
  "image/webp",
  "image/gif",
] as const;

export type NormalizedTextMediaType = (typeof NORMALIZED_TEXT_MEDIA_TYPES)[number];
export type NormalizedImageMediaType = (typeof NORMALIZED_IMAGE_MEDIA_TYPES)[number];

export type NormalizedToolChoice =
  | "auto"
  | "required"
  | "none"
  | { type: "named"; name: string };

export interface NormalizedTextPart {
  type: "text";
  text: string;
}

export interface NormalizedDataPart {
  type: "data";
  mediaType: NormalizedTextMediaType;
  data: Uint8Array;
}

export interface NormalizedImagePart {
  type: "image";
  mediaType: NormalizedImageMediaType;
  data: Uint8Array;
}

export interface NormalizedToolCallPart {
  type: "tool-call";
  id: string;
  name: string;
  arguments: Record<string, unknown>;
}

export interface NormalizedToolResultPart {
  type: "tool-result";
  toolCallId: string;
  content: Array<NormalizedTextPart | NormalizedDataPart>;
}

export type NormalizedUserNormalPart =
  | NormalizedTextPart
  | NormalizedDataPart
  | NormalizedImagePart;

export type NormalizedUserPart = NormalizedUserNormalPart | NormalizedToolResultPart;
export type NormalizedAssistantPart = NormalizedTextPart | NormalizedToolCallPart;
export type NormalizedSystemPart = NormalizedTextPart | NormalizedDataPart;

export type NormalizedMessage =
  | { role: "system"; content: NormalizedSystemPart[] }
  | { role: "user"; content: NormalizedUserPart[] }
  | { role: "assistant"; content: NormalizedAssistantPart[] };

export interface NormalizedChatInput {
  messages: NormalizedMessage[];
  temperature?: number;
  maxTokens?: number;
  stopSequences?: string[];
  parallelToolCalls?: boolean;
  reasoning?: Record<string, unknown>;
  promptCacheKey?: string;
  promptCacheRetention?: string;
  extra?: Record<string, unknown>;
  stream?: boolean;
  tools?: ToolDefinition[];
  toolChoice?: NormalizedToolChoice;
  signal?: AbortSignal;
}

export interface NormalizedChatResponse {
  text: string;
  parts: NormalizedAssistantPart[];
  provider: string;
  model: string;
  protocol: string;
  usage?: {
    inputTokens?: number;
    outputTokens?: number;
    totalTokens?: number;
    cacheReadInputTokens?: number;
    cacheWriteInputTokens?: number;
    reasoningTokens?: number;
  };
  finishReason?: string;
  raw: unknown;
}

export type NormalizedStreamEvent =
  | { kind: "delta"; text: string }
  | { kind: "tool-call"; id: string; name: string; arguments: Record<string, unknown> }
  | {
      kind: "usage";
      inputTokens?: number;
      outputTokens?: number;
      totalTokens?: number;
      cacheReadInputTokens?: number;
      cacheWriteInputTokens?: number;
      reasoningTokens?: number;
    }
  | { kind: "finish"; reason: string }
  | { kind: "error"; message: string };

export class NormalizedChatError extends Error {
  override name = "NormalizedChatError";

  constructor(message: string) {
    super(message);
    this.name = "NormalizedChatError";
  }
}
