import { isRecord } from "../adapter.js";
import {
  NORMALIZED_IMAGE_MEDIA_TYPES,
  NORMALIZED_TEXT_MEDIA_TYPES,
  NormalizedChatError,
  type NormalizedChatInput,
  type NormalizedImageMediaType,
  type NormalizedMessage,
  type NormalizedTextMediaType,
  type NormalizedToolChoice,
} from "./types.js";

const TEXT_MEDIA = new Set<string>(NORMALIZED_TEXT_MEDIA_TYPES);
const IMAGE_MEDIA = new Set<string>(NORMALIZED_IMAGE_MEDIA_TYPES);

export function isNormalizedToolChoice(value: unknown): value is NormalizedToolChoice {
  if (value === "auto" || value === "required" || value === "none") return true;
  return isRecord(value) && value.type === "named" && typeof value.name === "string" && value.name.length > 0;
}

export function decodeUtf8Data(data: Uint8Array, mediaType: string): string {
  let text: string;
  try {
    text = new TextDecoder("utf-8", { fatal: true }).decode(data);
  } catch {
    throw new NormalizedChatError(`${mediaType} data must be valid UTF-8`);
  }
  if (mediaType === "application/json") {
    try {
      JSON.parse(text);
    } catch {
      throw new NormalizedChatError("application/json data must contain valid JSON");
    }
  }
  return text;
}

export function parseToolArgumentsStrict(raw: string): Record<string, unknown> {
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch {
    throw new NormalizedChatError("tool-call arguments must be a JSON object");
  }
  if (!isRecord(parsed)) {
    throw new NormalizedChatError("tool-call arguments must be a JSON object");
  }
  return parsed;
}

function isTextMedia(value: unknown): value is NormalizedTextMediaType {
  return typeof value === "string" && TEXT_MEDIA.has(value);
}

function isImageMedia(value: unknown): value is NormalizedImageMediaType {
  return typeof value === "string" && IMAGE_MEDIA.has(value);
}

function isBytes(value: unknown): value is Uint8Array {
  return value instanceof Uint8Array;
}

function matchesImageMagic(mediaType: NormalizedImageMediaType, data: Uint8Array): boolean {
  if (mediaType === "image/png") {
    return data.length >= 8
      && data[0] === 0x89 && data[1] === 0x50 && data[2] === 0x4e && data[3] === 0x47
      && data[4] === 0x0d && data[5] === 0x0a && data[6] === 0x1a && data[7] === 0x0a;
  }
  if (mediaType === "image/jpeg") {
    return data.length >= 3 && data[0] === 0xff && data[1] === 0xd8 && data[2] === 0xff;
  }
  if (mediaType === "image/gif") {
    return data.length >= 6
      && data[0] === 0x47 && data[1] === 0x49 && data[2] === 0x46 && data[3] === 0x38
      && (data[4] === 0x37 || data[4] === 0x39) && data[5] === 0x61;
  }
  return data.length >= 12
    && data[0] === 0x52 && data[1] === 0x49 && data[2] === 0x46 && data[3] === 0x46
    && data[8] === 0x57 && data[9] === 0x45 && data[10] === 0x42 && data[11] === 0x50;
}

function assertTextOrDataPart(part: unknown, label: string): void {
  if (!isRecord(part) || typeof part.type !== "string") {
    throw new NormalizedChatError(`${label} part is invalid`);
  }
  if (part.type === "text") {
    if (typeof part.text !== "string") {
      throw new NormalizedChatError(`${label} text part must include a string`);
    }
    return;
  }
  if (part.type === "data") {
    if (!isTextMedia(part.mediaType) || !isBytes(part.data)) {
      throw new NormalizedChatError(`${label} data part must be UTF-8 text/plain, text/markdown, or application/json`);
    }
    decodeUtf8Data(part.data, part.mediaType);
    return;
  }
  if (part.type === "image") {
    throw new NormalizedChatError(`${label} cannot include image parts`);
  }
  throw new NormalizedChatError(`${label} part type "${part.type}" is not allowed`);
}

function assertImagePart(part: Record<string, unknown>): void {
  if (!isImageMedia(part.mediaType) || !isBytes(part.data) || part.data.length === 0) {
    throw new NormalizedChatError("image parts must be non-empty PNG, JPEG, WebP, or GIF bytes");
  }
  if (!matchesImageMagic(part.mediaType, part.data)) {
    throw new NormalizedChatError(`image bytes do not match media type ${part.mediaType}`);
  }
}

function assertUserContent(content: unknown): void {
  if (!Array.isArray(content) || content.length === 0) {
    throw new NormalizedChatError("user messages require a non-empty content array");
  }
  const kinds = content.map((part) => {
    if (!isRecord(part) || typeof part.type !== "string") {
      throw new NormalizedChatError("user content part is invalid");
    }
    return part.type;
  });
  const hasToolResult = kinds.some((type) => type === "tool-result");
  const hasNormal = kinds.some((type) => type === "text" || type === "data" || type === "image");
  if (hasToolResult && hasNormal) {
    throw new NormalizedChatError("user content cannot mix normal parts with tool results");
  }
  if (hasToolResult) {
    for (const part of content) {
      if (!isRecord(part) || part.type !== "tool-result" || typeof part.toolCallId !== "string") {
        throw new NormalizedChatError("tool-result parts require a toolCallId");
      }
      if (!Array.isArray(part.content) || part.content.length === 0) {
        throw new NormalizedChatError("tool-result content must be a non-empty text or data collection");
      }
      for (const inner of part.content) {
        if (isRecord(inner) && inner.type === "image") {
          throw new NormalizedChatError("image tool results are not supported");
        }
        assertTextOrDataPart(inner, "tool-result");
      }
    }
    return;
  }
  for (const part of content) {
    if (!isRecord(part)) throw new NormalizedChatError("user content part is invalid");
    if (part.type === "text" || part.type === "data") {
      assertTextOrDataPart(part, "user");
      continue;
    }
    if (part.type === "image") {
      assertImagePart(part);
      continue;
    }
    throw new NormalizedChatError(`user content part type "${String(part.type)}" is not allowed`);
  }
}

function assertAssistantContent(content: unknown): void {
  if (!Array.isArray(content) || content.length === 0) {
    throw new NormalizedChatError("assistant messages require a non-empty content array");
  }
  let sawToolCall = false;
  for (const part of content) {
    if (!isRecord(part) || typeof part.type !== "string") {
      throw new NormalizedChatError("assistant content part is invalid");
    }
    if (part.type === "data" || part.type === "tool-result" || part.type === "image") {
      throw new NormalizedChatError("assistant output cannot include data, image, or tool-result parts");
    }
    if (part.type === "text") {
      if (sawToolCall) {
        throw new NormalizedChatError("assistant text is not allowed after the first tool call");
      }
      if (typeof part.text !== "string") {
        throw new NormalizedChatError("assistant text part must include a string");
      }
      continue;
    }
    if (part.type === "tool-call") {
      if (typeof part.id !== "string" || typeof part.name !== "string" || !isRecord(part.arguments)) {
        throw new NormalizedChatError("assistant tool-call parts require id, name, and object arguments");
      }
      sawToolCall = true;
      continue;
    }
    throw new NormalizedChatError(`assistant content part type "${part.type}" is not allowed`);
  }
}

function assertSystemContent(content: unknown): void {
  if (!Array.isArray(content) || content.length === 0) {
    throw new NormalizedChatError("system messages require a non-empty content array");
  }
  for (const part of content) {
    if (isRecord(part) && (part.type === "image" || part.type === "tool-call" || part.type === "tool-result")) {
      throw new NormalizedChatError("system messages may only contain text or UTF-8 data parts");
    }
    assertTextOrDataPart(part, "system");
  }
}

export function validateNormalizedMessage(message: unknown): asserts message is NormalizedMessage {
  if (!isRecord(message) || typeof message.role !== "string") {
    throw new NormalizedChatError("normalized message is invalid");
  }
  if (message.role === "system") {
    assertSystemContent(message.content);
    return;
  }
  if (message.role === "user") {
    assertUserContent(message.content);
    return;
  }
  if (message.role === "assistant") {
    assertAssistantContent(message.content);
    return;
  }
  throw new NormalizedChatError(`normalized message role "${message.role}" is not allowed`);
}

export function validateNormalizedChatInput(input: NormalizedChatInput): void {
  if (!Array.isArray(input.messages) || input.messages.length === 0) {
    throw new NormalizedChatError("normalized chat input requires messages");
  }
  for (const message of input.messages) validateNormalizedMessage(message);
  if (input.toolChoice !== undefined && !isNormalizedToolChoice(input.toolChoice)) {
    throw new NormalizedChatError("toolChoice must be auto, required, none, or a named tool");
  }
}

export function joinTextAndData(
  parts: ReadonlyArray<{ type: string; text?: string; mediaType?: string; data?: Uint8Array }>,
): string {
  return parts.map((part) => {
    if (part.type === "text") return part.text ?? "";
    if (part.type === "data" && part.data && part.mediaType) {
      return decodeUtf8Data(part.data, part.mediaType);
    }
    return "";
  }).join("");
}
