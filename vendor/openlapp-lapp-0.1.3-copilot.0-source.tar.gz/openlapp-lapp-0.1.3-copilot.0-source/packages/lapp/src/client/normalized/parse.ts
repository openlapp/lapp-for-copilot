import type { AdapterContext, LappStreamEventUnion } from "../adapter.js";
import { isRecord } from "../adapter.js";
import { parseToolArgumentsStrict, validateNormalizedMessage } from "./validate.js";
import {
  NormalizedChatError,
  type NormalizedAssistantPart,
  type NormalizedChatResponse,
  type NormalizedStreamEvent,
} from "./types.js";

function finish(parts: NormalizedAssistantPart[], ctx: AdapterContext, raw: unknown, extras: {
  model?: string;
  finishReason?: string;
  usage?: NormalizedChatResponse["usage"];
}): NormalizedChatResponse {
  validateNormalizedMessage({ role: "assistant", content: parts });
  return {
    text: parts.filter((part) => part.type === "text").map((part) => part.text).join(""),
    parts,
    provider: ctx.providerId,
    model: extras.model ?? ctx.model,
    protocol: ctx.protocol,
    ...(extras.finishReason !== undefined ? { finishReason: extras.finishReason } : {}),
    ...(extras.usage !== undefined ? { usage: extras.usage } : {}),
    raw,
  };
}

function pushAssistantPart(parts: NormalizedAssistantPart[], part: NormalizedAssistantPart): void {
  if (part.type === "text" && parts.some((existing) => existing.type === "tool-call")) {
    throw new NormalizedChatError("assistant text is not allowed after the first tool call");
  }
  if (part.type === "text" && part.text.length === 0 && parts.some((existing) => existing.type === "text")) {
    return;
  }
  parts.push(part);
}

export function parseNormalizedResponse(
  protocol: string,
  raw: unknown,
  ctx: AdapterContext,
): NormalizedChatResponse {
  if (protocol === "openai-chat-completions") {
    if (!isRecord(raw) || !Array.isArray(raw.choices) || !isRecord(raw.choices[0])) {
      throw new NormalizedChatError("invalid openai-chat-completions response");
    }
    const choice = raw.choices[0];
    const message = isRecord(choice.message) ? choice.message : undefined;
    if (!message) throw new NormalizedChatError("invalid openai-chat-completions response");
    const parts: NormalizedAssistantPart[] = [];
    if (Array.isArray(message.content)) {
      for (const item of message.content) {
        if (!isRecord(item) || typeof item.type !== "string") {
          throw new NormalizedChatError("invalid openai-chat-completions response");
        }
        if (item.type === "text" || item.type === "output_text") {
          if (typeof item.text !== "string") {
            throw new NormalizedChatError("invalid openai-chat-completions response");
          }
          pushAssistantPart(parts, { type: "text", text: item.text });
          continue;
        }
        throw new NormalizedChatError("assistant output cannot include data, image, or tool-result parts");
      }
    } else if (typeof message.content === "string" && message.content.length > 0) {
      pushAssistantPart(parts, { type: "text", text: message.content });
    } else if (message.content !== undefined && message.content !== null && typeof message.content !== "string") {
      throw new NormalizedChatError("assistant output cannot include data, image, or tool-result parts");
    }
    if (message.tool_calls !== undefined) {
      if (!Array.isArray(message.tool_calls)) {
        throw new NormalizedChatError("invalid openai-chat-completions response");
      }
      for (const call of message.tool_calls) {
        if (
          !isRecord(call)
          || typeof call.id !== "string"
          || !isRecord(call.function)
          || typeof call.function.name !== "string"
          || typeof call.function.arguments !== "string"
        ) {
          throw new NormalizedChatError("invalid openai-chat-completions response");
        }
        pushAssistantPart(parts, {
          type: "tool-call",
          id: call.id,
          name: call.function.name,
          arguments: parseToolArgumentsStrict(call.function.arguments),
        });
      }
    }
    if (parts.length === 0) parts.push({ type: "text", text: "" });
    return finish(parts, ctx, raw, {
      model: typeof raw.model === "string" ? raw.model : undefined,
      finishReason: typeof choice.finish_reason === "string" ? choice.finish_reason : undefined,
    });
  }

  if (protocol === "openai-responses") {
    if (!isRecord(raw) || !Array.isArray(raw.output)) {
      throw new NormalizedChatError("invalid openai-responses response");
    }
    const parts: NormalizedAssistantPart[] = [];
    for (const item of raw.output) {
      if (!isRecord(item) || typeof item.type !== "string") {
        throw new NormalizedChatError("invalid openai-responses response");
      }
      if (item.type === "message" || item.type === "output_text") {
        const contents = Array.isArray(item.content) ? item.content : [item];
        for (const content of contents) {
          if (!isRecord(content) || typeof content.type !== "string") {
            throw new NormalizedChatError("invalid openai-responses response");
          }
          if (content.type === "output_text" || content.type === "text" || content.type === "message_output_text") {
            if (typeof content.text !== "string") {
              throw new NormalizedChatError("invalid openai-responses response");
            }
            pushAssistantPart(parts, { type: "text", text: content.text });
            continue;
          }
          throw new NormalizedChatError("assistant output cannot include data, image, or tool-result parts");
        }
        continue;
      }
      if (item.type === "function_call") {
        if (typeof item.call_id !== "string" || typeof item.name !== "string" || typeof item.arguments !== "string") {
          throw new NormalizedChatError("invalid openai-responses response");
        }
        pushAssistantPart(parts, {
          type: "tool-call",
          id: item.call_id,
          name: item.name,
          arguments: parseToolArgumentsStrict(item.arguments),
        });
        continue;
      }
      if (item.type === "function_call_output" || item.type === "input_image" || item.type === "image") {
        throw new NormalizedChatError("assistant output cannot include data, image, or tool-result parts");
      }
    }
    if (parts.length === 0 && typeof raw.output_text === "string") {
      parts.push({ type: "text", text: raw.output_text });
    }
    if (parts.length === 0) parts.push({ type: "text", text: "" });
    return finish(parts, ctx, raw, {
      model: typeof raw.model === "string" ? raw.model : undefined,
      finishReason: typeof raw.status === "string" ? raw.status : undefined,
    });
  }

  if (protocol === "anthropic-messages") {
    if (!isRecord(raw) || !Array.isArray(raw.content)) {
      throw new NormalizedChatError("invalid anthropic-messages response");
    }
    const parts: NormalizedAssistantPart[] = [];
    for (const item of raw.content) {
      if (!isRecord(item) || typeof item.type !== "string") {
        throw new NormalizedChatError("invalid anthropic-messages response");
      }
      if (item.type === "text") {
        if (typeof item.text !== "string") {
          throw new NormalizedChatError("invalid anthropic-messages response");
        }
        pushAssistantPart(parts, { type: "text", text: item.text });
        continue;
      }
      if (item.type === "tool_use") {
        if (typeof item.id !== "string" || typeof item.name !== "string") {
          throw new NormalizedChatError("invalid anthropic-messages response");
        }
        if (!isRecord(item.input)) {
          throw new NormalizedChatError("tool-call arguments must be a JSON object");
        }
        pushAssistantPart(parts, {
          type: "tool-call",
          id: item.id,
          name: item.name,
          arguments: item.input,
        });
        continue;
      }
      throw new NormalizedChatError("assistant output cannot include data, image, or tool-result parts");
    }
    if (parts.length === 0) parts.push({ type: "text", text: "" });
    return finish(parts, ctx, raw, {
      model: typeof raw.model === "string" ? raw.model : undefined,
      finishReason: typeof raw.stop_reason === "string" ? raw.stop_reason : undefined,
    });
  }

  throw new NormalizedChatError(`unsupported protocol: ${protocol}`);
}

export async function* parseNormalizedStream(
  events: AsyncIterable<LappStreamEventUnion>,
): AsyncGenerator<NormalizedStreamEvent> {
  let sawToolCall = false;
  for await (const event of events) {
    if (event.kind === "delta") {
      if (sawToolCall) {
        throw new NormalizedChatError("assistant text is not allowed after the first tool call");
      }
      yield event;
      continue;
    }
    if (event.kind === "tool-call") {
      sawToolCall = true;
      yield {
        kind: "tool-call",
        id: event.id,
        name: event.name,
        arguments: parseToolArgumentsStrict(event.arguments),
      };
      continue;
    }
    yield event;
  }
}
