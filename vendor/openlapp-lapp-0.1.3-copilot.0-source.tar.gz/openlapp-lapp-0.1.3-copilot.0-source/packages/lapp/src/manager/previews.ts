/** In-memory model-discovery proposals for the V2 manager host. */

export const MODEL_PREVIEW_TTL_MS = 5 * 60 * 1000;
export const MODEL_PREVIEW_LIMIT = 8;

export interface DiscoveredRemoteModel {
  id: string;
  name?: string;
}

export interface ModelDiscoveryProposal {
  previewId: string;
  operationId: string;
  providerId: string;
  expectedRevision: string;
  fetched: DiscoveredRemoteModel[];
  createdAt: number;
}

export type PreviewTakeResult =
  | { status: "ok"; proposal: ModelDiscoveryProposal }
  | { status: "missing" }
  | { status: "expired" }
  | { status: "consumed" };

export interface ModelPreviewStore {
  begin(operationId: string): AbortController;
  end(operationId: string, controller: AbortController): void;
  put(proposal: ModelDiscoveryProposal): void;
  take(previewId: string): PreviewTakeResult;
  cancel(operationId: string): boolean;
  size(): number;
}

export function createModelPreviewStore(now: () => number = Date.now): ModelPreviewStore {
  const proposals = new Map<string, ModelDiscoveryProposal>();
  const inFlight = new Map<string, AbortController>();
  const consumed = new Set<string>();

  function purgeExpired(): void {
    const t = now();
    for (const [id, proposal] of proposals) {
      if (t - proposal.createdAt > MODEL_PREVIEW_TTL_MS) proposals.delete(id);
    }
  }

  function dropOperation(operationId: string): boolean {
    let removed = false;
    for (const [id, proposal] of proposals) {
      if (proposal.operationId === operationId) {
        proposals.delete(id);
        removed = true;
      }
    }
    return removed;
  }

  return {
    begin(operationId) {
      const existing = inFlight.get(operationId);
      if (existing) existing.abort();
      dropOperation(operationId);
      const controller = new AbortController();
      inFlight.set(operationId, controller);
      return controller;
    },

    end(operationId, controller) {
      if (inFlight.get(operationId) === controller) inFlight.delete(operationId);
    },

    put(proposal) {
      purgeExpired();
      dropOperation(proposal.operationId);
      while (proposals.size >= MODEL_PREVIEW_LIMIT) {
        let oldestId: string | undefined;
        let oldestTime = Number.POSITIVE_INFINITY;
        for (const [id, entry] of proposals) {
          if (entry.createdAt < oldestTime) {
            oldestTime = entry.createdAt;
            oldestId = id;
          }
        }
        if (!oldestId) break;
        proposals.delete(oldestId);
      }
      proposals.set(proposal.previewId, proposal);
    },

    take(previewId) {
      if (consumed.has(previewId)) return { status: "consumed" };
      const proposal = proposals.get(previewId);
      if (!proposal) return { status: "missing" };
      if (now() - proposal.createdAt > MODEL_PREVIEW_TTL_MS) {
        proposals.delete(previewId);
        return { status: "expired" };
      }
      proposals.delete(previewId);
      consumed.add(previewId);
      return { status: "ok", proposal };
    },

    cancel(operationId) {
      let cancelled = false;
      const controller = inFlight.get(operationId);
      if (controller) {
        controller.abort();
        inFlight.delete(operationId);
        cancelled = true;
      }
      if (dropOperation(operationId)) cancelled = true;
      return cancelled;
    },

    size() {
      purgeExpired();
      return proposals.size;
    },
  };
}
